/** @file  queue_linked.c
 * -------------------------------------
 * @author Zi Feng (Alex) Ou, 169025748, ouxx5748@mylaurier.ca
 *
 * @version 2025-05-04
 *
 * -------------------------------------
 */
//==================================================================================
// Includes
#include "queue_linked.h"

//==================================================================================
// Local Helper Functions

// your code here, if any

//==================================================================================
// Functions

queue_linked* queue_initialize() {

	// your code here

	queue_linked *queue = malloc(sizeof(queue_linked));

	if (queue != NULL) {
		queue->front = NULL;
		queue->rear = NULL;
		queue->count = 0;
	}

	return queue;

}

void queue_destroy(queue_linked **source) {

	// your code here

	queue_node *curr = (*source)->front;

	while (curr != NULL) {
		queue_node *temp = curr;
		curr = curr->next;
		free(temp);
	}

	free(*source);
	*source = NULL;

	return;
}

bool queue_empty(const queue_linked *source) {

	// your code here

	return source->count == 0;
}

int queue_count(const queue_linked *source) {

	// your code here

	return source->count;
}

bool queue_insert(queue_linked *source, const data_type *item) {

	// your code here

	queue_node *new_node = malloc(sizeof(queue_node));

	if (new_node == NULL)
		return false;

	new_node->item = *item;
	new_node->next = NULL;

	if (queue_empty(source)) {
		source->front = source->rear = new_node;
	} else {
		source->rear->next = new_node;
		source->rear = new_node;
	}

	source->count++;

	return true;

}

bool queue_peek(const queue_linked *source, data_type *item) {

	// your code here

	if (queue_empty(source))
		return false;

	*item = source->front->item;

	return true;

}

bool queue_remove(queue_linked *source, data_type *item) {

	// your code here

	if (queue_empty(source))
		return false;

	queue_node *temp = source->front;
	*item = temp->item;
	source->front = temp->next;

	if (source->front == NULL) {
		source->rear = NULL;
	}

	free(temp);
	source->count--;

	return true;

}

bool queue_equal(const queue_linked *source, const queue_linked *target) {

	// your code here

	if (source->count != target->count)
		return false;

	queue_node *src = source->front;
	queue_node *tar = target->front;

	while (src != NULL) {
		if (data_compare(&src->item, &tar->item) != 0)
			return false;
		src = src->next;
		tar = tar->next;
	}

	return true;
}

bool queue_copy(queue_linked **target, const queue_linked *source) {

	// your code here

	if (*target != NULL) {
		queue_destroy(target);
	}

	*target = queue_initialize();

	if (*target == NULL)
		return false;

	queue_node *curr = source->front;

	while (curr != NULL) {
		if (!queue_insert(*target, &curr->item))
			return false;
		curr = curr->next;
	}

	return true;

}

void queue_append(queue_linked *target, queue_linked *source) {

	// your code here

	if (queue_empty(source))
		return;

	if (queue_empty(target)) {
		target->front = source->front;
		target->rear = source->rear;
	} else {
		target->rear->next = source->front;
		target->rear = source->rear;
	}

	target->count += source->count;
	source->front = source->rear = NULL;
	source->count = 0;

	return;
}

void queue_combine(queue_linked *target, queue_linked *source1,
		queue_linked *source2) {

	// your code here

	while (!queue_empty(source1) || !queue_empty(source2)) {
		if (!queue_empty(source1)) {
			queue_node *node = source1->front;
			source1->front = node->next;
			node->next = NULL;
			if (queue_empty(target)) {
				target->front = target->rear = node;
			} else {
				target->rear->next = node;
				target->rear = node;
			}
			target->count++;
			source1->count--;
		}
		if (!queue_empty(source2)) {
			queue_node *node = source2->front;
			source2->front = node->next;
			node->next = NULL;
			if (queue_empty(target)) {
				target->front = target->rear = node;
			} else {
				target->rear->next = node;
				target->rear = node;
			}
			target->count++;
			source2->count--;
		}
	}

	source1->rear = NULL;
	source2->rear = NULL;

	return;
}

void queue_split_alt(queue_linked *target1, queue_linked *target2,
		queue_linked *source) {

	// your code here

	bool change = true;

	while (!queue_empty(source)) {
		queue_node *node = source->front;
		source->front = node->next;
		node->next = NULL;

		if (change) {
			if (queue_empty(target1))
				target1->front = target1->rear = node;
			else {
				target1->rear->next = node;
				target1->rear = node;
			}
			target1->count++;
		} else {
			if (queue_empty(target2))
				target2->front = target2->rear = node;
			else {
				target2->rear->next = node;
				target2->rear = node;
			}
			target2->count++;
		}
		change = !change;
		source->count--;
	}

	source->rear = NULL;

	return;
}

void queue_print(const queue_linked *source) {
	char string[200];
	queue_node *current = source->front;

	while (current != NULL) {
		data_string(string, sizeof string, &current->item);
		printf("%s\n", string);
		current = current->next;
	}
	return;
}
