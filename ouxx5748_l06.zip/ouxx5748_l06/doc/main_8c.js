var main_8c =
[
    [ "FOODS_FILE", "main_8c.htm#a63a23585c7ef0a8b0de473f7a9e7b25a", null ],
    [ "SEP", "main_8c.htm#a95cf1ca63ff303311d342d1a53d51f38", null ],
    [ "TST", "main_8c.htm#ad03da240b462e9f42e2d083ac343c9ed", null ],
    [ "main", "main_8c.htm#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "test_queue_generic", "main_8c.htm#a68800f5994f37ac7143644c903c08821", null ],
    [ "test_stack_generic", "main_8c.htm#a26a047bf7b1c2d00e80dddfbf279af57", null ]
];