var food_8h =
[
    [ "food_struct", "structfood__struct.htm", "structfood__struct" ],
    [ "BOOL_STR", "food_8h.htm#ae6884e951887c44b96cde996ae49b3d9", null ],
    [ "CALORIES_HEADER", "food_8h.htm#a61260334bc00b9cb019a93056024a247", null ],
    [ "FOOD_FIELDS", "food_8h.htm#a12a8902d41719b0ba477183e825f445b", null ],
    [ "HEADER_WIDTH", "food_8h.htm#a48ac712e64002b9191deea9d20592c1b", null ],
    [ "LINE_LENGTH", "food_8h.htm#ad5131de0b5004c64db5e79e8aac7471e", null ],
    [ "NAME_HEADER", "food_8h.htm#a2f5933378cd5f162041fe0bf422bf5fa", null ],
    [ "NAME_LENGTH", "food_8h.htm#af71324c57f05ff9e24bd384925dd6b17", null ],
    [ "ORIGIN_HEADER", "food_8h.htm#a2986ce8b6819f1de6bf11a4d018066b7", null ],
    [ "VEG_HEADER", "food_8h.htm#abd957bae24f27eee2d4c517a269e6449", null ],
    [ "food_compare", "food_8h.htm#ac81510f10e37300fb4442df18b861204", null ],
    [ "food_copy", "food_8h.htm#a6713a7fd116bae89f8e0aa0e118f5cd9", null ],
    [ "food_hash", "food_8h.htm#af3245d45450f8e05c9b094a6ca6158e2", null ],
    [ "food_init", "food_8h.htm#a494956adba1073849938a3c9d08e4e09", null ],
    [ "food_key", "food_8h.htm#a3f43a21e1390fd471d93ce4232ee971c", null ],
    [ "food_string", "food_8h.htm#a1007e16dcf4374853a765587fd557f43", null ],
    [ "origins_menu", "food_8h.htm#abc1dec4d8f73b1d02d850a0f499e1bc7", null ],
    [ "ORIGINS", "food_8h.htm#a5f9601c818e312b8b05794f038c19cc3", null ],
    [ "ORIGINS_COUNT", "food_8h.htm#a603c97f02ec3b1503c7024009dd5b678", null ]
];