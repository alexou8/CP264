var annotated_dup =
[
    [ "food_array", "structfood__array.htm", "structfood__array" ],
    [ "food_struct", "structfood__struct.htm", "structfood__struct" ],
    [ "int_struct", "structint__struct.htm", "structint__struct" ],
    [ "queue_linked", "structqueue__linked.htm", "structqueue__linked" ],
    [ "QUEUE_NODE", "struct_q_u_e_u_e___n_o_d_e.htm", "struct_q_u_e_u_e___n_o_d_e" ],
    [ "stack_linked", "structstack__linked.htm", "structstack__linked" ],
    [ "STACK_NODE", "struct_s_t_a_c_k___n_o_d_e.htm", "struct_s_t_a_c_k___n_o_d_e" ]
];