var struct_s_t_a_c_k___n_o_d_e =
[
    [ "item", "struct_s_t_a_c_k___n_o_d_e.htm#a4dfe2509690de196b7c25abd665e70b2", null ],
    [ "next", "struct_s_t_a_c_k___n_o_d_e.htm#afccf9ecaac1bf2c881751fb539892da5", null ]
];