var structstack__linked =
[
    [ "top", "structstack__linked.htm#a34830ebe4243289febd46c42f412da53", null ]
];