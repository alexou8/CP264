var structqueue__linked =
[
    [ "count", "structqueue__linked.htm#a2ecc719f835b128b801edba627232601", null ],
    [ "front", "structqueue__linked.htm#a0e2bee0d466252441401dc6f77a7403c", null ],
    [ "rear", "structqueue__linked.htm#adaebddd406c991175c9271b394f88f2a", null ]
];