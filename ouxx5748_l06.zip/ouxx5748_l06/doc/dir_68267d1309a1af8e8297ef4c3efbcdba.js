var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "data.h", "data_8h.htm", "data_8h" ],
    [ "food.h", "food_8h.htm", "food_8h" ],
    [ "food_utilities.h", "food__utilities_8h.htm", "food__utilities_8h" ],
    [ "int_data.c", "int__data_8c.htm", "int__data_8c" ],
    [ "int_data.h", "int__data_8h.htm", "int__data_8h" ],
    [ "main.c", "main_8c.htm", "main_8c" ],
    [ "queue_linked.c", "queue__linked_8c.htm", "queue__linked_8c" ],
    [ "queue_linked.h", "queue__linked_8h.htm", "queue__linked_8h" ],
    [ "stack_linked.c", "stack__linked_8c.htm", "stack__linked_8c" ],
    [ "stack_linked.h", "stack__linked_8h.htm", "stack__linked_8h" ]
];