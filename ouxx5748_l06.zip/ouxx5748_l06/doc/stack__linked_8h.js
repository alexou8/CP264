var stack__linked_8h =
[
    [ "STACK_NODE", "struct_s_t_a_c_k___n_o_d_e.htm", "struct_s_t_a_c_k___n_o_d_e" ],
    [ "stack_linked", "structstack__linked.htm", "structstack__linked" ],
    [ "stack_node", "stack__linked_8h.htm#a477aed8b44cc6e0a41c0f170501f20f0", null ],
    [ "stack_combine", "stack__linked_8h.htm#a075eee4e37d254725d9761555f9b620f", null ],
    [ "stack_copy", "stack__linked_8h.htm#a826addbfa6b295c3c9d4d5621b4ecdeb", null ],
    [ "stack_destroy", "stack__linked_8h.htm#a2d9598b9d9618b3da006d7624db3a04e", null ],
    [ "stack_empty", "stack__linked_8h.htm#a7b90e3e7b58251deb4c985bd80b6bd68", null ],
    [ "stack_equal", "stack__linked_8h.htm#a716089010126213994ea45b8bc5b1138", null ],
    [ "stack_initialize", "stack__linked_8h.htm#a833f48ae5ddd26ab79c3d41ef24895f9", null ],
    [ "stack_peek", "stack__linked_8h.htm#a182001575093e3844a4a5553de945a29", null ],
    [ "stack_pop", "stack__linked_8h.htm#a3c3ab76847e2973d2ae516a4dc0f45c6", null ],
    [ "stack_print", "stack__linked_8h.htm#a7c40feef9bc74d4d35e1c954e1185493", null ],
    [ "stack_push", "stack__linked_8h.htm#a7901f27b06f70a7fa49b20e6fcb1ff84", null ],
    [ "stack_split_alt", "stack__linked_8h.htm#a8ab9076e368530a49be09e43412e0000", null ]
];