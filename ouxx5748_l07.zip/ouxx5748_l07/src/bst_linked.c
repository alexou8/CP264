/** @file  bst_linked.c
 * -------------------------------------
 * @author David Brown, 123456789, dbrown@wlu.ca
 *
 * @version 2025-05-04
 *
 * -------------------------------------
 */
#include "bst_linked.h"

// Macro for comparing node heights
#define MAX_HEIGHT(a,b) ((a) > (b) ? a : b)

//==================================================================================
// Private Helper Functions

/**
 * Private helper function to print contents of BST in preorder.
 *
 * @param node - pointer to bst_node
 */
static void bst_print_aux(bst_node *node) {
	char string[200];

	if (node != NULL) {
		data_string(string, sizeof string, &node->item);
		printf("%s, ", string);
		bst_print_aux(node->left);
		bst_print_aux(node->right);
	}
	return;
}

/**
 * Initializes a new BST node with a copy of item.
 *
 * @param item - pointer to the value to copy to the node
 * @return - a pointer to a new BST node, NULL if memory not allocated
 */
static bst_node* bst_node_initialize(const data_type *item) {
	bst_node *node = malloc(sizeof *node);

	if (node != NULL) {
		data_copy(&node->item, item);
		node->height = 1;
		node->left = NULL;
		node->right = NULL;
	}
	return node;
}

/**
 * Determines the height of node - empty nodes have a height of 0.
 *
 * @param node - pointer to a BST node
 * @return - the height of the current node
 */
static int bst_node_height(const bst_node *node) {
	int height = 0;

	if (node != NULL) {
		height = node->height;
	}
	return height;
}

/**
 * Updates the height of a node. Its height is the max of the heights of its
 * child nodes, plus 1.
 *
 * @param node - pointer to a BST node
 */
static void bst_update_height(bst_node *node) {
	int left_height = bst_node_height(node->left);
	int right_height = bst_node_height(node->right);

	node->height = MAX_HEIGHT(left_height, right_height) + 1;
	return;
}

/**
 * Inserts a copy of item into source. Insertion must preserve the BST definition.
 * item may appear only once in source.
 *
 * @param source - pointer to a BST
 * @param node - pointer to a BST node
 * @param item - the item to insert
 * @return - true if item inserted, false otherwise
 */
static bool bst_insert_aux(bst_linked *source, bst_node **node,
		const data_type *item) {
	bool inserted = false;

	if (*node == NULL) {
		// Base case: add a new node containing the item.
		*node = bst_node_initialize(item);
		source->count += 1;
		inserted = true;
	} else {
		// Compare the node data_type against the new item.
		int comp = data_compare(item, &(*node)->item);

		if (comp < 0) {
			// General case: check the left subsource.
			inserted = bst_insert_aux(source, &(*node)->left, item);
		} else if (comp > 0) {
			// General case: check the right subsource.
			inserted = bst_insert_aux(source, &(*node)->right, item);
		}
	}
	if (inserted) {
		// Update the node height if any of its children have been changed.
		bst_update_height(*node);
	}
	return inserted;
}

// other auxiliary functions here

/**
 * Frees all nodes in a BST recursively (post-order).
 *
 * @param node - pointer to a node in the BST
 */
static void bst_destroy_aux(bst_node *node) {
	if (node != NULL) {
		bst_destroy_aux(node->left);
		bst_destroy_aux(node->right);
		free(node);
	}
}

/**
 * Inorder traversal and fills the items array recursively.
 *
 * @param node - current node
 * @param items - array to store BST items
 * @param index - pointer to current index in the array
 */
static void bst_inorder_aux(bst_node *node, data_type *items, int *index) {
	if (node != NULL) {
		bst_inorder_aux(node->left, items, index);
		items[*index] = node->item;
		(*index)++;
		bst_inorder_aux(node->right, items, index);
	}
}

/**
 * Preorder traversal and fills the items array recursively.
 *
 * @param node - current node
 * @param items - array to store BST items
 * @param index - pointer to current index in the array
 */
static void bst_preorder_aux(bst_node *node, data_type *items, int *index) {
	if (node != NULL) {
		items[*index] = node->item;
		(*index)++;
		bst_preorder_aux(node->left, items, index);
		bst_preorder_aux(node->right, items, index);
	}
}

/**
 * Postorder traversal and fills the items array recursively.
 *
 * @param node - current node
 * @param items - array to store BST items
 * @param index - pointer to current index in the array
 */
static void bst_postorder_aux(bst_node *node, data_type *items, int *index) {
	if (node != NULL) {
		bst_postorder_aux(node->left, items, index);
		bst_postorder_aux(node->right, items, index);
		items[*index] = node->item;
		(*index)++;
	}
}

/**
 * Private helper for removing a node from a BST.
 *
 * @param node - current subtree root
 * @param key - key to search for
 * @param item - pointer to store removed item
 * @param removed - pointer to bool flag that tracks successful removal
 * @return - updated subtree root
 */
static bst_node* bst_remove_aux(bst_node *node, const data_type *key,
		data_type *item, bool *removed) {
	if (node == NULL) {
		return NULL;
	}

	int cmp = data_compare(key, &node->item);

	if (cmp < 0) {
		node->left = bst_remove_aux(node->left, key, item, removed);
	} else if (cmp > 0) {
		node->right = bst_remove_aux(node->right, key, item, removed);
	} else {
		*item = node->item;
		*removed = true;
		if (node->left == NULL && node->right == NULL) {
			free(node);
			return NULL;
		} else if (node->left == NULL) {
			bst_node *temp = node->right;
			free(node);
			return temp;
		} else if (node->right == NULL) {
			bst_node *temp = node->left;
			free(node);
			return temp;
		} else {
			bst_node *succ = node->right;
			while (succ->left != NULL) {
				succ = succ->left;
			}
			node->item = succ->item;
			node->right = bst_remove_aux(node->right, &succ->item, item,
					removed);
		}
	}

	return node;
}

/**
 * Copies all nodes from source tree into a new tree recursively.
 *
 * @param node - pointer to current node in source tree
 * @return - pointer to new copied node
 */
static bst_node* bst_copy_aux(const bst_node *node) {
	if (node == NULL) {
		return NULL;
	}

	bst_node *new_node = (bst_node*) malloc(sizeof(bst_node));
	if (new_node == NULL) {
		return NULL;
	}

	new_node->item = node->item;
	new_node->height = node->height;
	new_node->left = bst_copy_aux(node->left);
	new_node->right = bst_copy_aux(node->right);

	return new_node;
}

/**
 * Counts the number of leaf nodes in the BST.
 *
 * @param node - current node
 * @return - number of leaf nodes in this subtree
 */
static int bst_leaf_count_aux(const bst_node *node) {
	if (node == NULL) {
		return 0;
	}

	if (node->left == NULL && node->right == NULL) {
		return 1;
	}

	return bst_leaf_count_aux(node->left) + bst_leaf_count_aux(node->right);
}

/**
 * Counts the number of nodes with exactly one child.
 *
 * @param node - current node
 * @return - number of one-child nodes in this subtree
 */
static int bst_one_child_count_aux(const bst_node *node) {
	if (node == NULL) {
		return 0;
	}

	int count = 0;

	if ((node->left == NULL && node->right != NULL)
			|| (node->left != NULL && node->right == NULL)) {
		count = 1;
	}

	return count + bst_one_child_count_aux(node->left)
			+ bst_one_child_count_aux(node->right);
}

/**
 * Counts the number of nodes with exactly two children.
 *
 * @param node - current node
 * @return - number of two-child nodes in this subtree
 */
static int bst_two_child_count_aux(const bst_node *node) {
	if (node == NULL) {
		return 0;
	}

	int count = 0;

	if (node->left != NULL && node->right != NULL) {
		count = 1;
	}

	return count + bst_two_child_count_aux(node->left)
			+ bst_two_child_count_aux(node->right);
}

/**
 * Counts nodes with 0, 1, and 2 children.
 *
 * @param node - current node
 * @param zero - pointer to count of nodes with 0 children (leaf nodes)
 * @param one - pointer to count of nodes with 1 child
 * @param two - pointer to count of nodes with 2 children
 */
static void bst_node_counts_aux(const bst_node *node, int *zero, int *one,
		int *two) {
	if (node == NULL) {
		return;
	}

	bool check_left = node->left != NULL;
	bool check_right = node->right != NULL;

	if (check_left && check_right) {
		(*two)++;
	} else if (check_left || check_right) {
		(*one)++;
	} else {
		(*zero)++;
	}

	bst_node_counts_aux(node->left, zero, one, two);
	bst_node_counts_aux(node->right, zero, one, two);
}

/**
 * Checks if the subtree is balanced.
 *
 * @param node - current node
 * @return - height of the subtree if balanced, -1 if unbalanced
 */
static int bst_balanced_aux(const bst_node *node) {
	if (node == NULL) {
		return 0;
	}

	int left_h = bst_balanced_aux(node->left);
	if (left_h == -1)
		return -1;

	int right_h = bst_balanced_aux(node->right);
	if (right_h == -1)
		return -1;

	if (abs(left_h - right_h) > 1) {
		return -1;
	}

	return (left_h > right_h ? left_h : right_h) + 1;
}

/**
 * Checks if the subtree is a valid BST using min/max constraints.
 *
 * @param node - current node
 * @param min - pointer to minimum allowed value (NULL if no min)
 * @param max - pointer to maximum allowed value (NULL if no max)
 * @return - true if subtree is valid, false otherwise
 */
static bool bst_valid_aux(const bst_node *node, const data_type *min,
		const data_type *max) {
	if (node == NULL) {
		return true;
	}
	if ((min != NULL && data_compare(&node->item, min) <= 0)
			|| (max != NULL && data_compare(&node->item, max) >= 0)) {
		return false;
	}

	return bst_valid_aux(node->left, min, &node->item)
			&& bst_valid_aux(node->right, &node->item, max);
}

/**
 * Compares two BSTs for structural and value equality.
 *
 * @param node1 - current node in first tree
 * @param node2 - current node in second tree
 * @return - true if equal, false otherwise
 */
static bool bst_equal_aux(const bst_node *node1, const bst_node *node2) {
	if (node1 == NULL && node2 == NULL) {
		return true;
	}

	if (node1 == NULL || node2 == NULL) {
		return false;
	}

	if (data_compare(&node1->item, &node2->item) != 0) {
		return false;
	}

	return bst_equal_aux(node1->left, node2->left)
			&& bst_equal_aux(node1->right, node2->right);
}

//==================================================================================
// Functions

bst_linked* bst_initialize() {
	// Allocate memory to the list header
	bst_linked *source = malloc(sizeof *source);

	if (source) {
		// Initialize the list structure
		source->root = NULL;
		source->count = 0;
	}
	// returns NULL if malloc fails
	return source;
}

void bst_destroy(bst_linked **source) {

	// your code here

	if (source != NULL && *source != NULL) {
		bst_destroy_aux((*source)->root);
		free(*source);
		*source = NULL;
	}

	return;
}

bool bst_empty(const bst_linked *source) {

	// your code here

	if (source == NULL || source->count == 0) {
		return true;
	}

	return false;
}

int bst_count(const bst_linked *source) {

	// your code here

	if (source == NULL) {
		return 0;
	}

	return source->count;
}

void bst_inorder(const bst_linked *source, data_type *items) {

	// your code here

	int index = 0;

	if (source != NULL && source->root != NULL) {
		bst_inorder_aux(source->root, items, &index);
	}

	return;
}

void bst_preorder(const bst_linked *source, data_type *items) {

	// your code here

	int index = 0;

	if (source != NULL && source->root != NULL) {
		bst_preorder_aux(source->root, items, &index);
	}

	return;
}

void bst_postorder(const bst_linked *source, data_type *items) {

	// your code here

	int index = 0;

	if (source != NULL && source->root != NULL) {
		bst_postorder_aux(source->root, items, &index);
	}

	return;
}

bool bst_insert(bst_linked *source, const data_type *item) {
	return bst_insert_aux(source, &(source->root), item);
}

bool bst_retrieve(const bst_linked *source, const data_type *key,
		data_type *item) {

	// your code here

	if (source == NULL || source->root == NULL || key == NULL || item == NULL) {
		return false;
	}

	bst_node *curr = source->root;

	while (curr != NULL) {
		int cmp = data_compare(key, &curr->item);

		if (cmp == 0) {
			*item = curr->item;
			return true;
		} else if (cmp < 0) {
			curr = curr->left;
		} else {
			curr = curr->right;
		}
	}

	return false;
}

bool bst_remove(bst_linked *source, const data_type *key, data_type *item) {

	// your code here

	if (source == NULL || source->root == NULL || key == NULL || item == NULL) {
		return false;
	}

	bool removed = false;
	source->root = bst_remove_aux(source->root, key, item, &removed);

	if (removed) {
		source->count--;
	}

	return removed;
}

bool bst_copy(bst_linked **target, const bst_linked *source) {

	// your code here

	if (source == NULL || target == NULL) {
		return false;
	}

	bst_linked *new_tree = (bst_linked*) malloc(sizeof(bst_linked));
	if (new_tree == NULL) {
		return false;
	}

	new_tree->count = source->count;
	new_tree->root = bst_copy_aux(source->root);

	if (source->count != 0 && new_tree->root == NULL) {
		// copy failed; clean up
		free(new_tree);
		return false;
	}

	*target = new_tree;

	return true;
}

bool bst_max(const bst_linked *source, data_type *item) {

	// your code here

	if (source == NULL || source->root == NULL || item == NULL) {
		return false;
	}

	bst_node *curr = source->root;

	while (curr->right != NULL) {
		curr = curr->right;
	}

	*item = curr->item;

	return true;
}

bool bst_min(const bst_linked *source, data_type *item) {

	// your code here

	if (source == NULL || source->root == NULL || item == NULL) {
		return false;
	}

	bst_node *curr = source->root;

	while (curr->left != NULL) {
		curr = curr->left;
	}

	*item = curr->item;

	return true;
}

int bst_leaf_count(const bst_linked *source) {

	// your code here

	if (source == NULL || source->root == NULL) {
		return 0;
	}

	return bst_leaf_count_aux(source->root);
}

int bst_one_child_count(const bst_linked *source) {

	// your code here

	if (source == NULL || source->root == NULL) {
		return 0;
	}

	return bst_one_child_count_aux(source->root);
}

int bst_two_child_count(const bst_linked *source) {

	// your code here

	if (source == NULL || source->root == NULL) {
		return 0;
	}

	return bst_two_child_count_aux(source->root);
}

void bst_node_counts(const bst_linked *source, int *zero, int *one, int *two) {

	// your code here

	if (zero != NULL)
		*zero = 0;
	if (one != NULL)
		*one = 0;
	if (two != NULL)
		*two = 0;

	if (source == NULL || source->root == NULL) {
		return;
	}

	bst_node_counts_aux(source->root, zero, one, two);
}

bool bst_balanced(const bst_linked *source) {

	// your code here

	if (source == NULL || source->root == NULL) {
		return true;
	}

	return bst_balanced_aux(source->root) != -1;
}

bool bst_valid(const bst_linked *source) {

	// your code here

	if (source == NULL || source->root == NULL) {
		return true;
	}

	return bst_valid_aux(source->root, NULL, NULL);
}

bool bst_equal(const bst_linked *target, const bst_linked *source) {

	// your code here

	if (target == NULL || source == NULL) {
		return false;
	}

	return bst_equal_aux(target->root, source->root);
}

void bst_print(const bst_linked *source) {
	// can print root height only if root is not NULL
	printf("  count: %d, height: %d, items:\n{", source->count,
			source->root ? source->root->height : 0);
	bst_print_aux(source->root);
	printf("}\n");
	return;
}
