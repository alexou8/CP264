/** @file  main.c
 * -------------------------------------
 * @author David Brown, 123456789, dbrown@wlu.ca
 *
 * @version 2025-05-04
 *
 * -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "data.h"
#include "bst_linked.h"

#define TST "===========================================\n"
#define SEP "-------------------------------------------\n"
/*
 int test_bst_generic(const data_type *values, int count) {
 printf(TST);
 printf("Testing bst_linked\n");
 printf(SEP);

 data_type item;
 char string[200];
 bst_linked *source = bst_initialize();

 printf("source = bst_initialize():\n");

 if(!source) {
 perror("bst could not be initialized");
 return 1;
 }
 printf("bst_print(source)\n");
 bst_print(source);
 printf(SEP);
 printf("bst_empty(source): %s\n", BOOL_STR(bst_empty(source)));
 printf(SEP);

 for(int i = 0; i < count; i++) {
 data_string(string, sizeof string, &values[i]);
 printf("bst_insert(source, %s)\n", string);
 bst_insert(source, &values[i]);
 }
 printf("bst_print(source)\n");
 bst_print(source);
 printf(SEP);
 printf("bst_empty(source): %s\n", BOOL_STR(bst_empty(source)));
 printf(SEP);
 printf("bst_count(source): %d\n", bst_count(source));
 printf(SEP);

 // other tests here
 printf("\nother tests here\n\n");

 printf(SEP);
 printf("bst_destroy(&source)\n");
 bst_destroy(&source);
 return 0;
 }
 */

int test_bst_generic(const data_type *values, int count) {
	printf(TST);
	printf("Testing bst_linked\n");
	printf(SEP);

	data_type item;
	char string[200];
	bst_linked *source = bst_initialize();

	printf("source = bst_initialize():\n");

	if (!source) {
		perror("bst could not be initialized");
		return 1;
	}

	printf("bst_print(source)\n");
	bst_print(source);
	printf(SEP);
	printf("bst_empty(source): %s\n", BOOL_STR(bst_empty(source)));
	printf(SEP);

	for (int i = 0; i < count; i++) {
		data_string(string, sizeof string, &values[i]);
		printf("bst_insert(source, %s)\n", string);
		bst_insert(source, &values[i]);
	}

	printf("bst_print(source)\n");
	bst_print(source);
	printf(SEP);
	printf("bst_empty(source): %s\n", BOOL_STR(bst_empty(source)));
	printf(SEP);
	printf("bst_count(source): %d\n", bst_count(source));
	printf(SEP);

	// === Additional Tests ===
	printf("\nExtra function tests:\n\n");

	// Retrieve test
	data_string(string, sizeof string, &values[2]);
	printf("bst_retrieve(source, %s): ", string);
	if (bst_retrieve(source, &values[2], &item)) {
		data_string(string, sizeof string, &item);
		printf("FOUND: %s\n", string);
	} else {
		printf("NOT FOUND\n");
	}

	// Max / Min
	if (bst_max(source, &item)) {
		data_string(string, sizeof string, &item);
		printf("bst_max: %s\n", string);
	}

	if (bst_min(source, &item)) {
		data_string(string, sizeof string, &item);
		printf("bst_min: %s\n", string);
	}

	// Node counts
	printf("bst_leaf_count: %d\n", bst_leaf_count(source));
	printf("bst_one_child_count: %d\n", bst_one_child_count(source));
	printf("bst_two_child_count: %d\n", bst_two_child_count(source));

	int zero = -1, one = -1, two = -1;
	bst_node_counts(source, &zero, &one, &two);
	printf("bst_node_counts -> zero: %d, one: %d, two: %d\n", zero, one, two);

	// Valid and Balanced
	printf("bst_valid: %s\n", BOOL_STR(bst_valid(source)));
	printf("bst_balanced: %s\n", BOOL_STR(bst_balanced(source)));

	// Traversals
	data_type *inorder = malloc(count * sizeof(data_type));
	data_type *preorder = malloc(count * sizeof(data_type));
	data_type *postorder = malloc(count * sizeof(data_type));

	printf("bst_inorder:\n");
	bst_inorder(source, inorder);
	for (int i = 0; i < count; i++) {
		data_string(string, sizeof string, &inorder[i]);
		printf("%s ", string);
	}
	printf("\n");

	printf("bst_preorder:\n");
	bst_preorder(source, preorder);
	for (int i = 0; i < count; i++) {
		data_string(string, sizeof string, &preorder[i]);
		printf("%s ", string);
	}
	printf("\n");

	printf("bst_postorder:\n");
	bst_postorder(source, postorder);
	for (int i = 0; i < count; i++) {
		data_string(string, sizeof string, &postorder[i]);
		printf("%s ", string);
	}
	printf("\n");

	free(inorder);
	free(preorder);
	free(postorder);

	// Copy and Equal
	bst_linked *copy = NULL;
	printf("bst_copy(&copy, source): %s\n", BOOL_STR(bst_copy(&copy, source)));
	printf("bst_equal(copy, source): %s\n", BOOL_STR(bst_equal(copy, source)));

	// Remove a node
	data_string(string, sizeof string, &values[3]);
	printf("bst_remove(source, %s): ", string);
	if (bst_remove(source, &values[3], &item)) {
		data_string(string, sizeof string, &item);
		printf("Removed: %s\n", string);
	} else {
		printf("Not Found\n");
	}

	printf("bst_print(source) after removal\n");
	bst_print(source);

	// Destroy copy
	printf("bst_destroy(&copy)\n");
	bst_destroy(&copy);

	// ========================
	printf(SEP);
	printf("bst_destroy(&source)\n");
	bst_destroy(&source);
	return 0;
}

/**
 * Change commenting in data.h in order to use a given data type.
 *
 * @param argc - unused
 * @param argv - unused
 * @return
 */
int main(int argc, char *argv[]) {
	setbuf(stdout, NULL);

#ifdef USE_INT
	// integer test values
	const data_type values[] = { { 11 }, { 7 }, { 6 }, { 9 }, { 8 }, { 15 }, {
			12 }, { 18 } };
	int values_count = sizeof values / sizeof *values;
#endif

#ifdef USE_FOOD
    // food test values
    food_array foods;
    food_array_init(&foods);
    FILE *fp = fopen(FOODS_FILE, "r");
    foods_read(fp, &foods);
    fclose(fp);
    const data_type *values = foods.items;
    int values_count = foods.count;
#endif

	test_bst_generic(values, values_count);
	return 0;
}
