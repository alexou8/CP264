var annotated_dup =
[
    [ "bst_linked", "structbst__linked.htm", "structbst__linked" ],
    [ "BST_NODE", "struct_b_s_t___n_o_d_e.htm", "struct_b_s_t___n_o_d_e" ],
    [ "food_array", "structfood__array.htm", "structfood__array" ],
    [ "food_struct", "structfood__struct.htm", "structfood__struct" ],
    [ "int_struct", "structint__struct.htm", "structint__struct" ]
];