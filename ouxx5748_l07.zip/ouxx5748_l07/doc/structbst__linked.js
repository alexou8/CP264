var structbst__linked =
[
    [ "count", "structbst__linked.htm#ab58d23807e52171c3a7aac52012a712e", null ],
    [ "root", "structbst__linked.htm#aaf3839020dba20c529555e0503e8c420", null ]
];