var data_8h =
[
    [ "BOOL_STR", "data_8h.htm#ae6884e951887c44b96cde996ae49b3d9", null ],
    [ "data_compare", "data_8h.htm#af96974604ce7e4920c0c21a4d8e0b734", null ],
    [ "data_copy", "data_8h.htm#a6eb7a6aaf0891c6dded92408c4d004f6", null ],
    [ "data_string", "data_8h.htm#a6c224df7aff9a6096fa4cec502188c1b", null ],
    [ "USE_INT", "data_8h.htm#a53d2338f2c14a855acba5e87deb6a3f2", null ],
    [ "data_type", "data_8h.htm#a86b6861bef89a2ff4baf74a32776ce96", null ]
];